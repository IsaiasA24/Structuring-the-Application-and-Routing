﻿using MvcProduct.Interfaces;

namespace MvcProduct.Services
{
    public class SystemTimeProvider : ITimeProvider
    {
        public DateTimeOffset UtcNow() => DateTimeOffset.UtcNow;
    }
}
