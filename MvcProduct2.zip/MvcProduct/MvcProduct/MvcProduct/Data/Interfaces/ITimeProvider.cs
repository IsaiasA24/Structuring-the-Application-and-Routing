﻿namespace MvcProduct.Interfaces
{
    public interface ITimeProvider
    {
        DateTimeOffset UtcNow();
    }
}
