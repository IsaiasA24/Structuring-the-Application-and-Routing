﻿using Microsoft.AspNetCore.Mvc;
using MvcProduct.Interfaces;

namespace MvcProduct.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TimeController : Controller
    {
        private readonly ITimeProvider _timeProvider;

        public TimeController(ITimeProvider timeProvider)
        {
            _timeProvider = timeProvider;
        }
        [HttpGet("clock")]
        public IActionResult Index()
        {
            return Ok(new {utcNow = _timeProvider.UtcNow()});
        }
    }
}
